// Test_SDK.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <stdio.h>
#include <string>
#include <windows.h>

//include dataglove class
#include "VHand30.h"

int _tmain(int argc, _TCHAR* argv[])
{
	//create a new dataglove instance
	VHand30 *dataglove = new VHand30;

	//set dataglove connection parameter (COM port nt important, IP address got from VHand3Manager)
	dataglove->SetConnectionParameters(1,"192.168.2.239");

	//connect with the USB connection, created comport = 1
	int ret = dataglove->Connect(CONN_WIFI,STREAM_FINGERS_QUATERNION);
	fprintf(stderr,"CONNECT RET: %d\n",ret);

	//wait for connection established
	long start = ::GetTickCount();
	while ((dataglove->Connected == NOT_CONNECTED))
	{
		if ((::GetTickCount()-start)>5000){
			//timeout, error with the connection
			fprintf(stderr,"Cannot connect to the dataglove\n");
			dataglove->Disconnect();
			return 0;
		}
	}

	//show dataglove informations
	char label[VHAND_STRLEN];
	int ID=0;
	dataglove->GetID(label,&ID);
	fprintf(stderr,"LABEL:%s ID:%d\n",label,ID);

	//firmware version
	int fw1,fw2,fw3;
	dataglove->GetFWVersion(&fw1,&fw2,&fw3);
	fprintf(stderr,"FIRMWARE:%d.%d.%d\n",fw1,fw2,fw3);

	//access point configuration
	char ssid[VHAND_STRLEN], pwd[VHAND_STRLEN];
	dataglove->GetAPNSettings(ssid,pwd);
	fprintf(stderr,"SSID: %s PWD:%s\n",ssid,pwd);

	//show network information
	char ip[VHAND_STRLEN], gw[VHAND_STRLEN], nm[VHAND_STRLEN];
	int DHCP;
	dataglove->GetWiFiSettings(ip,nm,gw,&DHCP);
	fprintf(stderr,"IP: %s NM:%s GW:%s DHCP:%d\n",ip,nm,gw,DHCP);
	
	while ((::GetTickCount()-start)<10000){
		Sleep(100);
		int connstatus = dataglove->GetConnectionStatus();
		//is the dataglove conected with the Wifi interface?
		if (connstatus == WIFI_CONNECTED){
			double fing[5];
			double roll,pitch,yaw;
			dataglove->GetFingers(fing);
			dataglove->GetAttitude(&roll,&pitch,&yaw);
			unsigned int time = dataglove->GetLastPackageTime();
			fprintf(stderr,"TIME: %04d\n",time);
			fprintf(stderr,"F1:%.1f F2:%1.f F3:%.1f F4:%.1f F5:%.1f\n",fing[0],fing[1],fing[2],fing[3],fing[4]);
			fprintf(stderr,"ROLL:%.1f PITCH:%.1f YAW:%.1f\n",roll,pitch,yaw);
		}
	}
	//disconnect socket
	dataglove->Disconnect();
	Sleep(1000);
	//turn off module
	dataglove->TurnOFF(CONN_WIFI);
	Sleep(1000);
	//exit
	return 0;
}

